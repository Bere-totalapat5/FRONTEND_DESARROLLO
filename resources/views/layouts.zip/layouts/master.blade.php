<!DOCTYPE html>
<html lang="es">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>@yield('head-title')</title>

    <!-- vendor css -->
    <link href="{{ $entorno["version_pages"]["version"] }}/lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="{{ $entorno["version_pages"]["version"] }}/lib/Ionicons/css/ionicons.css" rel="stylesheet">
    @yield('estilos')
    <!-- Slim CSS -->
    <link rel="stylesheet" href="{{ $entorno["version_pages"]["version"] }}/css/slim.css">

    <!-- Iconos y Meta -->
    <link rel="apple-touch-icon" href="pages/ico/60.png">
    <link rel="apple-touch-icon" sizes="76x76" href="pages/ico/76.png">
    <link rel="apple-touch-icon" sizes="120x120" href="pages/ico/120.png"> 
    <link rel="apple-touch-icon" sizes="152x152" href="pages/ico/152.png">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">

    
  </head>
  <body>
    
      @yield('cuerpo')
      
      @yield('modales')
    
    <script src="{{ $entorno["version_pages"]["version"] }}/lib/jquery/js/jquery.js"></script>
    <script src="{{ $entorno["version_pages"]["version"] }}/lib/popper.js/js/popper.js"></script>
    <script src="{{ $entorno["version_pages"]["version"] }}/lib/bootstrap/js/bootstrap.js"></script>
    <script src="{{ $entorno["version_pages"]["version"] }}/lib/jquery.cookie/js/jquery.cookie.js"></script>
    @yield('scripts-libs')
    <script src="{{ $entorno["version_pages"]["version"] }}/js/slim.js"></script>

    @yield('scripts-functions')
  
    <div id="pg-visible-sm" class="visible-sm"></div>
    <div id="pg-visible-xs" class="visible-xs"></div>
    
  </body>
</html>